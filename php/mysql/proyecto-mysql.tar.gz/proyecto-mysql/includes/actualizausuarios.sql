ALTER TABLE usuarios ADD rol VARCHAR(20);
ALTER TABLE usuarios ADD ultimo_acceso DATETIME;
ALTER TABLE usuarios ADD ip VARCHAR(20);
