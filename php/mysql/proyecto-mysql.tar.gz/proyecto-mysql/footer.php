<footer class="blockquote-footer fixed-bottom">
<div class="footer">
    <p>Gestión de incidencias del <a class="text-center" href="https://iesamachado.org" target="_blank">IES Antonio Machado</a>. Desarrollado por Gabriel Karajallo y Raul Romero </p>
</div>    
</footer>


<style>
    .footer{
        text-align: center;
    }

    p{
        color: #6c757d;
    }
    a{
        color: #6c757d;
    }
</style>
</body>
</html>